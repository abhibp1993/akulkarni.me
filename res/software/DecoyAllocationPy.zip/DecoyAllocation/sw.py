import networkx as nx


def pre_exists(graph, y, player):
    pre = set()
    for v in y:
        for u, _ in graph.in_edges(v):
            if graph.nodes[u]["turn"] == player:
                pre.add(u)

    return pre


def pre_forall(graph, y, player):
    pre = set()
    for v in y:
        for u, _ in graph.in_edges(v):
            post = set()
            for _, w in graph.out_edges(u):
                post.add(w)

            if post.issubset(y):
                pre.add(u)

    return pre


def surewin(graph, final, player, debug_dict=None):
    y = final

    while True:
        y1 = pre_exists(graph, y, player)
        y2 = pre_forall(graph, y, player)
        pre = set.union(*(y, y1, y2))
        
        # print(y, y1, y2)
        if pre == y:
            break

        y = pre

    return y

