import networkx as nx


def filter_edges(graph, swin2):
    
    sr_edges = set()
    for u in graph.nodes():
        # Node u is P2 node, which is sure-winning for P2
        if u in swin2 and graph.nodes[u]["turn"] == 2:     
            for (_, v) in graph.out_edges(u):
                if v in swin2:
                    sr_edges.add((u, v))

        # Node u is P2 node, which is sure-winning for P1
        if u in swin2 and graph.nodes[u]["turn"] == 1:     
            for (_, v) in graph.out_edges(u):
                if v in swin2:                  # Redundant. Because, P1's node 'u' can be in swin2 only if all outedges from 'u' lead to node in swin2.
                    sr_edges.add((u, v))

    return sr_edges


def filter_hgame(graph, swin2, subjectively_rationalizable_edges):
    hgame = nx.MultiDiGraph()

    for n in swin2:
        hgame.add_node(n, turn=graph.nodes[n]["turn"])

    hgame.add_edges_from(subjectively_rationalizable_edges)

    return hgame


