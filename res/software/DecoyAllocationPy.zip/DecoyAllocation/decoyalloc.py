from memory_profiler import profile

import sw
import copy


def single_state_dswin(hgame, candidate_decoys):
    protect_range = dict()
    for n in candidate_decoys:
        protect_range[n] = list(sw.surewin(hgame, {n}, 1))

    return protect_range


# @profile
def greedymax(hgame, final, prange_single_state, decoy_budget, debug_dict=None):
    # Identify the states where we can place the decoys. 
    #   Recall this is same as swin2. 
    candidate_decoys = set(hgame.nodes()) - final

    # Initialize data structures to keep track of decoys
    iter_count = 0
    decoys = set()
    cover = set()

    # Initialize debug_dict 
    iter_debug_dict_key = "greedymax_iter_data"
    if debug_dict is not None:
        debug_dict[iter_debug_dict_key] = dict()
        debug_dict[iter_debug_dict_key][iter_count] = {
                        "composed_prange": dict(),
                        "next_decoy": -1,
                        "decoys": list(decoys),
                        "cover": list(cover),
                    }

    # Iteratively allocate decoys
    while (len(candidate_decoys - cover) > 0 and len(decoys) < decoy_budget):
        
        # Identify candidate decoys in this iteration
        candidate_decoys_iter = candidate_decoys - decoys           # This could be candidate_decoys - cover.

        # Compute composed deceptive sure winning regions
        composed_prange = list()
        for new_decoy in candidate_decoys_iter:
            composed_decoys = list(decoys) + [new_decoy]
            composed_dswin = sw.surewin(hgame, set(composed_decoys), 1)
            composed_prange.append((new_decoy, list(composed_dswin)))
        
        # Find the decoy set which has maximum protection range
        max_prange_iter = max(composed_prange, key=lambda x:len(x[1]))
        next_decoy = max_prange_iter[0]
        prange_next_decoy = max_prange_iter[1]

        # Update tracking data structures
        decoys.add(next_decoy)
        cover.update(set(prange_next_decoy))

        # Update debug dictionary, if applicable
        if debug_dict is not None:
            debug_dict[iter_debug_dict_key][iter_count] = {
                    "composed_prange": {item[0]: item[1] for item in composed_prange},
                    "next_decoy": next_decoy,
                    "decoys": list(decoys),
                    "cover": list(cover),
                }

        # Update iteration count
        iter_count += 1
        
    return decoys, cover, debug_dict