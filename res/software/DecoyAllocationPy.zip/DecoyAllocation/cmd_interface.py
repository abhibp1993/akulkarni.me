import argparse
import json
import os

import demo 

if __name__ == "__main__":
    
    # Parse inputs
    parser = argparse.ArgumentParser()
    parser.add_argument("n", type=int, help="Number of nodes in randomly generated attack-defend game graph.")
    parser.add_argument("a", type=int, help="Maximum number of edges per node in the generated attack-defend game graph.")
    parser.add_argument("k", type=int, help="Decoy budget.")
    parser.add_argument("f", type=int, help="Number of critical states in the generated attack-defend game graph.")
    parser.add_argument("-s", type=int, default=None, help="Random seed to use (for repeatability).")
    parser.add_argument("-o", type=str, nargs='?', default=os.getcwd(), help="Path to store randomly generated graph.")
    
    args = parser.parse_args()
    
    n = args.n
    a = args.a
    k = args.k
    f = args.f
    s = args.s
    
    # Initialize a dictionary to collect information debug information. 
    #   This dictionary should be passed to functions as optional argument "debug_dict". 
    #   [Remark: This is not the best way to do it. Figure out a better way. ]
    json_soln = dict()
    json_soln["config"] = {
        'n': n,
        'a': a,
        'k': k,
        'f': f,
        's': s
    }
    # print(json_soln["config"])

    # Solve the problem.
    json_soln = demo.run_demo(n, a, k, f, s, debug_dict=json_soln)

    # Print information
    print()
    print("- Configuration: {0}".format(json_soln["config"]))
    print("- Size of SWin of P1: {0}".format(len(json_soln["swin1"])))
    print("- Size of SWin of P2: {0}".format(len(json_soln["swin2"])))
    print("- Size of Protection Range: {0}".format(len(json_soln["prange"])))
    print("- Value of Deception (0: No advantage, 1: Maximum advantage): {0}".format(json_soln["benefit"]))
    print("- Time to Solve (in ms): {0}".format(json_soln["time"]))
    print("- Peak Memory Utilization (in KiB): {0}".format(json_soln["mem_peak"]))
