import random
import networkx as nx
import time
import tracemalloc

import sw
import dsw
import decoyalloc


# =============================================================================================
# PUBLIC FUNCTIONS
# =============================================================================================
def run_demo(n, a, k, f, s, debug_dict=None):
    
    # Generate random graph
    graph, final = generate_rnd_graph(n, a, f, s)

    # Enable profilers
    tracemalloc.start()
    _, start_memory_peak = tracemalloc.get_traced_memory()
    start_mem_snapshot = tracemalloc.take_snapshot()
    start_time = time.time()

    # Call decoy allocation routine
    _, _, _, debug_dict = allocate_decoys(graph, final, k, debug_dict)

    # Disable profiler 
    stop_time = time.time()
    _, stop_memory_peak = tracemalloc.get_traced_memory()    
    stop_mem_snapshot = tracemalloc.take_snapshot()
    tracemalloc.stop()

    # Compute time taken (in milliseconds)
    time_usage = (stop_time - start_time) * 1000 

    # Compute memory usage (in bytes)
    mem_blocks_diff = stop_mem_snapshot.compare_to(start_mem_snapshot, 'traceback')
    mem_usage_bytes = sum([diff.size for diff in mem_blocks_diff]) / 1000.
    mem_usage_peak_Kb = (stop_memory_peak - start_memory_peak) / 1024.      # in Kilobytes

    # Update debug_dict with graph and final state information
    debug_dict["game"] = {
        "nodes": [{"id": node, "turn": graph.nodes[node]["turn"]} for node in graph.nodes()],
        "edges": list(graph.edges())
    }
    debug_dict["final"] = list(final)
    debug_dict["time"] =  time_usage
    debug_dict["mem"] = mem_usage_bytes
    debug_dict["mem_peak"] = mem_usage_peak_Kb

    return debug_dict


# =============================================================================================
# HELPER FUNCTIONS
# =============================================================================================

def generate_rnd_graph(num_nodes, out_degree, num_final, rnd_seed):
    
    # Random seed
    random.seed(rnd_seed)

    # Create nodes and partition into P1 and P2 nodes
    nodes = list(range(num_nodes))
    random.shuffle(nodes)
    p1_nodes = nodes[:int(num_nodes/2)] 
    p2_nodes = nodes[int(num_nodes/2):]
    
    nodes = range(num_nodes)        # shuffling mutates nodes.
    nodes_partition = p1_nodes, p2_nodes

    # Select final states and make them sink states
    final = set(random.sample(range(num_nodes), num_final))

    # Generate random edges (the function ensures the final states are sink)
    edges = generate_edges(nodes_partition, out_degree, final)

    # Instantiate networkx graph
    graph = nx.MultiDiGraph()
    
    graph.add_nodes_from(nodes)
    for node in p1_nodes:
        graph.nodes[node]["turn"] = 1
    
    for node in p2_nodes:
        graph.nodes[node]["turn"] = 2

    graph.add_edges_from(edges)

    return graph, final


def generate_edges(nodes_partition, out_degree, final):
    p1_nodes = nodes_partition[0]
    p2_nodes = nodes_partition[1]

    edges = set()       # avoid repeating edges
    for node in p1_nodes:
        if node in final:
            continue

        out_nbrs = random.sample(p2_nodes, random.randint(1, out_degree))

        for nbr in out_nbrs:
            edges.add((node, nbr))  

    for node in p2_nodes:
        if node in final:
            continue

        out_nbrs = random.sample(p1_nodes, random.randint(1, out_degree))

        for nbr in out_nbrs:
            edges.add((node, nbr)) 

    return list(edges)


# @profile
def allocate_decoys(graph, final, num_decoys, debug_dict=None):

    # Compute non-deceptive sure winning region
    swin2 = sw.surewin(graph, final, 2, debug_dict)     
    swin1 = set(graph.nodes()) - swin2      
    
    # Compute subjectively rationalizable actions for both players
    subjectively_rationalizable_edges = dsw.filter_edges(graph, swin2)  

    # Generate hypergame 
    hgame = dsw.filter_hgame(graph, swin2, subjectively_rationalizable_edges)
    
    # Compute individual DSWin's (read prange as protection range)
    prange_single_state = decoyalloc.single_state_dswin(hgame, swin2 - final)

    # Run GreedyMax algorithm
    decoys, prange, debug_dict = decoyalloc.greedymax(hgame, final, prange_single_state, num_decoys, debug_dict=debug_dict)

    # Update debug information 
    if debug_dict is not None:
        debug_dict["swin1"] = list(swin1)
        debug_dict["swin2"] = list(swin2)
        debug_dict["sr_edges"] = list(subjectively_rationalizable_edges)
        debug_dict["decoys"] = list(decoys)
        debug_dict["prange"] = list(set.union(prange, swin1))
        # debug_dict["benefit"] = float(len(set.difference(prange, set.union(swin1, decoys)))) / (len(swin2) - len(final)) #float(len(set.union(prange, swin1))) / (len(swin1) + len(decoys))
        debug_dict["benefit"] = float(len(set.union(prange, swin1)) - len(swin1)) / (len(swin2) - len(final))
        debug_dict["single_state_prange"] = prange_single_state
        debug_dict["hgame"] = {
            "nodes": [{"id": node, "turn": hgame.nodes[node]["turn"]} for node in hgame.nodes()],
            "edges": list(hgame.edges())
        }


    # Return results
    return decoys, swin1, prange, debug_dict