Main file: cmd_interface.py. 

Parameters: n (nodes), a (max outdegree), k (decoy budget), f (number of final states)
Optional Params: s (random seed)